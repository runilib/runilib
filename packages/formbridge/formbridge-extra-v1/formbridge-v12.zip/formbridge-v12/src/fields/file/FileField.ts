/**
 * formbridge — File Upload Field
 * ────────────────────────────────
 * Cross-platform file upload field.
 * Web: input[type=file] with drag & drop.
 * Native: expo-image-picker + expo-document-picker (optional deps).
 */

// ─── FileValue — platform-agnostic file reference ────────────────────────────

export interface FileValue {
  /** Platform-agnostic URI (blob URL on web, file:// on native) */
  uri:       string;
  /** Original file name */
  name:      string;
  /** MIME type */
  type:      string;
  /** File size in bytes */
  size:      number;
  /** Base64 encoded data (optional, for direct upload) */
  base64?:   string;
  /** Width (images only) */
  width?:    number;
  /** Height (images only) */
  height?:   number;
  /** Whether the file was selected from the camera */
  fromCamera?: boolean;
}

// ─── FileFieldMeta ────────────────────────────────────────────────────────────

export type FileSourceType = 'gallery' | 'camera' | 'documents' | 'all';

export interface FileFieldMeta {
  _fileEnabled:         true;
  /** Accepted MIME types (e.g. ['image/jpeg', 'image/png', 'application/pdf']) */
  _fileAccept:          string[];
  /** Max file size in bytes */
  _fileMaxSize:         number | null;
  /** Max number of files (when multiple is true) */
  _fileMaxFiles:        number;
  /** Allow multiple files */
  _fileMultiple:        boolean;
  /** Show image preview after selection */
  _filePreview:         boolean;
  /** Preview max height in pixels */
  _filePreviewHeight:   number;
  /** Source type on native (gallery | camera | documents | all) */
  _fileSource:          FileSourceType;
  /** Request base64 encoding of selected files */
  _fileBase64:          boolean;
  /** Max image width/height for auto-resize on native (0 = no resize) */
  _fileImageMaxWidth:   number;
  _fileImageMaxHeight:  number;
  /** Image quality 0–1 for JPEG compression */
  _fileImageQuality:    number;
  /** Allow selecting videos */
  _fileAllowVideo:      boolean;
  /** Show a drag & drop zone on web */
  _fileDragDrop:        boolean;
  /** Custom drag & drop zone label */
  _fileDragDropLabel:   string;
}

// ─── Builder ──────────────────────────────────────────────────────────────────

export class FileFieldBuilder {
  private _meta: FileFieldMeta;
  private _label:       string;
  private _required:    boolean = false;
  private _requiredMsg: string  = 'Please select a file.';
  private _hint?:       string;
  private _disabled:    boolean = false;
  private _hidden:      boolean = false;

  constructor(label: string) {
    this._label = label;
    this._meta  = {
      _fileEnabled:        true,
      _fileAccept:         [],
      _fileMaxSize:        null,
      _fileMaxFiles:       1,
      _fileMultiple:       false,
      _filePreview:        false,
      _filePreviewHeight:  160,
      _fileSource:         'all',
      _fileBase64:         false,
      _fileImageMaxWidth:  0,
      _fileImageMaxHeight: 0,
      _fileImageQuality:   0.9,
      _fileAllowVideo:     false,
      _fileDragDrop:       true,
      _fileDragDropLabel:  'Drag & drop a file here, or click to browse',
    };
  }

  // ── Standard field methods ────────────────────────────────────

  required(message?: string): this {
    this._required    = true;
    this._requiredMsg = message ?? 'Please select a file.';
    return this;
  }

  hint(text: string): this {
    this._hint = text;
    return this;
  }

  disabled(value = true): this {
    this._disabled = value;
    return this;
  }

  hidden(value = true): this {
    this._hidden = value;
    return this;
  }

  // ── File-specific methods ─────────────────────────────────────

  /**
   * Accepted MIME types.
   * @example .accept(['image/jpeg', 'image/png', 'application/pdf'])
   * @example .accept(['image/*'])
   */
  accept(types: string[]): this {
    this._meta._fileAccept = types;
    return this;
  }

  /**
   * Max file size in bytes.
   * @example .maxSize(5 * 1024 * 1024)  // 5 MB
   */
  maxSize(bytes: number): this {
    this._meta._fileMaxSize = bytes;
    return this;
  }

  /** Allow multiple file selection. */
  multiple(max = 10): this {
    this._meta._fileMultiple  = true;
    this._meta._fileMaxFiles  = max;
    return this;
  }

  /** Show a preview of selected image(s). */
  preview(height = 160): this {
    this._meta._filePreview       = true;
    this._meta._filePreviewHeight = height;
    return this;
  }

  /**
   * On native: which source to use for file selection.
   * - 'gallery'   → photo gallery
   * - 'camera'    → camera
   * - 'documents' → document picker
   * - 'all'       → show action sheet to choose (default)
   */
  source(type: FileSourceType): this {
    this._meta._fileSource = type;
    return this;
  }

  /** Request base64 encoding of selected files (needed for some upload APIs). */
  withBase64(): this {
    this._meta._fileBase64 = true;
    return this;
  }

  /**
   * Auto-resize images before selection (native only).
   * @example .resize(1920, 1080, 0.85)
   */
  resize(maxWidth: number, maxHeight: number, quality = 0.9): this {
    this._meta._fileImageMaxWidth  = maxWidth;
    this._meta._fileImageMaxHeight = maxHeight;
    this._meta._fileImageQuality   = quality;
    return this;
  }

  /** Allow video files in addition to images. */
  allowVideo(): this {
    this._meta._fileAllowVideo = true;
    return this;
  }

  /**
   * Disable drag & drop on web (show just the button).
   */
  noDragDrop(): this {
    this._meta._fileDragDrop = false;
    return this;
  }

  /** Custom drag & drop zone label. */
  dragLabel(label: string): this {
    this._meta._fileDragDropLabel = label;
    return this;
  }

  // ─── Convenience presets ─────────────────────────────────────

  /** Preset for profile photo upload (images only, 5MB max, preview enabled). */
  static profilePhoto(label = 'Profile photo'): FileFieldBuilder {
    return new FileFieldBuilder(label)
      .accept(['image/jpeg', 'image/png', 'image/webp'])
      .maxSize(5 * 1024 * 1024)
      .preview()
      .source('gallery')
      .resize(1024, 1024, 0.85)
      .dragLabel('Click to upload a profile photo')
      .hint('JPG, PNG or WebP. Max 5 MB.');
  }

  /** Preset for document upload (PDF only, 10MB max). */
  static document(label = 'Document'): FileFieldBuilder {
    return new FileFieldBuilder(label)
      .accept(['application/pdf'])
      .maxSize(10 * 1024 * 1024)
      .source('documents')
      .dragLabel('Click to upload a PDF document')
      .hint('PDF only. Max 10 MB.');
  }

  /** Preset for a generic attachment (images + PDF, multiple). */
  static attachments(label = 'Attachments', max = 5): FileFieldBuilder {
    return new FileFieldBuilder(label)
      .accept(['image/*', 'application/pdf'])
      .maxSize(10 * 1024 * 1024)
      .multiple(max)
      .preview()
      .dragLabel(`Drag & drop up to ${max} files, or click to browse`)
      .hint(`Images or PDF. Max 10 MB each. Up to ${max} files.`);
  }

  /** Preset for CSV/Excel import. */
  static spreadsheet(label = 'Import file'): FileFieldBuilder {
    return new FileFieldBuilder(label)
      .accept([
        'text/csv',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      ])
      .maxSize(20 * 1024 * 1024)
      .source('documents')
      .dragLabel('Drop your CSV or Excel file here')
      .hint('CSV or XLSX. Max 20 MB.');
  }

  // ─── Build descriptor ─────────────────────────────────────────

  _build() {
    const validators: ((v: unknown) => string | null)[] = [];

    if (this._required) {
      validators.push((v: unknown) => {
        if (!v || (Array.isArray(v) && v.length === 0)) return this._requiredMsg;
        return null;
      });
    }

    if (this._meta._fileMaxSize !== null) {
      const maxBytes = this._meta._fileMaxSize;
      validators.push((v: unknown) => {
        const files = Array.isArray(v) ? v as FileValue[] : v ? [v as FileValue] : [];
        for (const f of files) {
          if (f.size > maxBytes) {
            const mb = (maxBytes / (1024 * 1024)).toFixed(0);
            return `File "${f.name}" is too large. Max size is ${mb} MB.`;
          }
        }
        return null;
      });
    }

    if (this._meta._fileAccept.length > 0) {
      const accepted = this._meta._fileAccept;
      validators.push((v: unknown) => {
        const files = Array.isArray(v) ? v as FileValue[] : v ? [v as FileValue] : [];
        for (const f of files) {
          const ok = accepted.some(pattern => {
            if (pattern.endsWith('/*')) {
              return f.type.startsWith(pattern.replace('/*', '/'));
            }
            return f.type === pattern;
          });
          if (!ok) return `File type "${f.type}" is not accepted.`;
        }
        return null;
      });
    }

    if (this._meta._fileMultiple && this._meta._fileMaxFiles > 0) {
      const max = this._meta._fileMaxFiles;
      validators.push((v: unknown) => {
        const files = Array.isArray(v) ? v : [];
        if (files.length > max) return `You can upload at most ${max} files.`;
        return null;
      });
    }

    return {
      _type:         'file' as const,
      _label:        this._label,
      _defaultValue: this._meta._fileMultiple ? [] : null,
      _required:     this._required,
      _requiredMsg:  this._requiredMsg,
      _hint:         this._hint,
      _disabled:     this._disabled,
      _hidden:       this._hidden,
      _trim:         false,
      _debounce:     0,
      _validators:   validators,
      ...this._meta,
    };
  }
}

/** Check if a descriptor is a file field */
export function isFileDescriptor(d: object): d is ReturnType<FileFieldBuilder['_build']> {
  return '_fileEnabled' in d;
}
