// ─── Feature: Masks ───────────────────────────────────────────────────────────
export { MaskedFieldBuilder }                          from './fields/mask/MaskedField';
export { isMaskedDescriptor }                          from './fields/mask/MaskedField';
export { MASKS, applyMask, extractRaw, parsePattern }  from './fields/mask/masks';
export { maskCompleteValidator }                       from './fields/mask/masks';
export type { MaskPreset, MaskResult, MaskToken, ApplyMaskOptions } from './fields/mask/masks';
export type { MaskedDescriptor, MaskedFieldMeta }      from './fields/mask/MaskedField';

// ─── Feature: Password strength ──────────────────────────────────────────────
export { scorePassword }                               from './fields/password/strength';
export { STRENGTH_CONFIG_STRICT }                      from './fields/password/strength';
export { STRENGTH_CONFIG_SIMPLE }                      from './fields/password/strength';
export { STRENGTH_CONFIG_FR }                          from './fields/password/strength';
export { PasswordStrengthMixin, isStrengthDescriptor } from './fields/password/PasswordWithStrength';
export { DEFAULT_STRENGTH_META }                       from './fields/password/PasswordWithStrength';
export type {
  StrengthResult,
  StrengthConfig,
  StrengthScoreLevel,
  StrengthRuleConfig,
  PasswordRule,
}                                                      from './fields/password/strength';
export type { PasswordStrengthMeta }                   from './fields/password/PasswordWithStrength';

// ─── Feature: File upload ─────────────────────────────────────────────────────
export { FileFieldBuilder, isFileDescriptor }          from './fields/file/FileField';
export type {
  FileValue,
  FileFieldMeta,
  FileSourceType,
}                                                      from './fields/file/FileField';

// ─── Web renderers (for integration into WebField.tsx) ────────────────────────
// These are imported dynamically inside useForm — not re-exported here.

// ─── Integration note ─────────────────────────────────────────────────────────
// To integrate these features into the main formbridge package:
// 1. Copy this entire src/ into formbridge/src/
// 2. In formbridge/src/hooks/useForm.ts, add checks for masked/strength/file
//    descriptors when rendering fields (see INTEGRATION.md)
// 3. Add exports from this index.ts to formbridge/src/index.ts
// 4. In formbridge/src/builders/field.ts, add:
//    masked: (label, pattern) => new MaskedFieldBuilder(label, pattern)
//    file:   (label) => new FileFieldBuilder(label)
